# E.V AI Assistant

Standalone Android project. Push these files to the `main` branch of its own GitHub repository to build a debug APK with GitHub Actions.

## Build
1. Create a separate GitHub repository for this app.
2. Upload the contents of this folder to its `main` branch, including `.github/workflows/build-apk.yml`.
3. Open Actions and run the workflow.
4. Download the `EV-AI-Assistant-APK` artifact from a successful run.

This package has not been built or tested by GitHub Actions yet. Debug APK only; not signed for Play Store release.
