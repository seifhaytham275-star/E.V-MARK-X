package com.ev.omni;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.content.SharedPreferences;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.text.InputType;
import android.widget.*;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(8, 12, 25);
    private final int PANEL = Color.rgb(18, 25, 45);
    private final int RED = Color.rgb(255, 55, 82);
    private final int BLUE = Color.rgb(35, 153, 255);
    private final int WHITE = Color.rgb(242, 247, 255);
    private final int MUTED = Color.rgb(155, 174, 202);
    private LinearLayout root, body, nav;
    private SharedPreferences prefs;
    private String page = "home";
    private final NumberFormat money = NumberFormat.getNumberInstance(Locale.US);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("ev_data", MODE_PRIVATE);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        showPage("home");
    }

    private GradientDrawable shape(int color, int stroke, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(radius);
        if (stroke != 0) d.setStroke(1, stroke);
        return d;
    }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView v = new TextView(this); v.setText(s); v.setTextSize(size); v.setTextColor(color);
        v.setTypeface(Typeface.create("sans-serif", bold ? Typeface.BOLD : Typeface.NORMAL));
        v.setGravity(Gravity.CENTER_VERTICAL); return v;
    }
    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l;
    }
    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l;
    }
    private LinearLayout.LayoutParams lp(int w, int h) { return new LinearLayout.LayoutParams(w, h); }
    private void pad(View v, int a) { v.setPadding(a,a,a,a); }
    private void gap(LinearLayout into, int h) { View v = new View(this); into.addView(v, lp(1,h)); }
    private TextView button(String label, int color) {
        TextView b = text(label, 14, WHITE, true); b.setGravity(Gravity.CENTER);
        b.setPadding(14, 12, 14, 12); b.setBackground(shape(color, color == PANEL ? BLUE : 0, 18)); return b;
    }
    private EditText edit(String hint, int type) {
        EditText e = new EditText(this); e.setSingleLine(true); e.setTextColor(WHITE); e.setHintTextColor(MUTED);
        e.setHint(hint); e.setTextSize(15); e.setInputType(type);
        e.setPadding(14, 8, 14, 8); e.setBackground(shape(Color.rgb(10,16,31), BLUE, 14)); return e;
    }
    private void showPage(String p) {
        page = p;
        root = column(); root.setBackground(new WebBackground()); root.setPadding(18, 12, 18, 10);
        setContentView(root);
        LinearLayout header = row();
        TextView logo = text("E.V", 28, RED, true);
        header.addView(logo, lp(-2, 48));
        TextView sub = text("  // OMNI SUIT", 11, BLUE, true); header.addView(sub, lp(-2,48));
        View space = new View(this); header.addView(space, new LinearLayout.LayoutParams(0,1,1));
        header.addView(text("● ONLINE", 10, Color.rgb(100,240,180), true));
        root.addView(header);
        TextView title = text(titleFor(p), 24, WHITE, true); root.addView(title, lp(-1, 46));
        TextView desc = text("YOUR PERSONAL DASHBOARD  •  LOCAL DATA", 10, MUTED, true); root.addView(desc, lp(-1, 24));
        ScrollView scroll = new ScrollView(this); body = column(); body.setPadding(0, 8, 0, 12); scroll.addView(body);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        render(p);
        nav = row(); nav.setPadding(0,8,0,0);
        String[][] items = {{"HOME","home"},{"WALLET","wallet"},{"CALORIES","calories"}};
        for (String[] item : items) {
            TextView b = button(item[0], page.equals(item[1]) ? RED : PANEL);
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0, 48, 1); bp.setMargins(3,0,3,0);
            nav.addView(b,bp); b.setOnClickListener(v -> showPage(item[1]));
        }
        root.addView(nav);
    }
    private String titleFor(String p) {
        if (p.equals("wallet")) return "WALLET / EXPENSES";
        if (p.equals("calories")) return "CALORIE LAB";
        return "SUIT CONTROL";
    }
    private void card(String title, String value, String note, int accent) {
        LinearLayout c = column(); c.setPadding(16,13,16,13); c.setBackground(shape(PANEL, accent, 20));
        TextView t = text(title.toUpperCase(Locale.ROOT), 11, MUTED, true); c.addView(t);
        TextView v = text(value, 25, WHITE, true); c.addView(v);
        TextView n = text(note, 11, accent, false); c.addView(n);
        LinearLayout.LayoutParams cp = lp(-1,-2); cp.setMargins(0,6,0,8); body.addView(c,cp);
    }
    private void section(String title) { gap(body,10); body.addView(text(title,16,BLUE,true),lp(-1,34)); }
    private void render(String p) {
        if (p.equals("home")) {
            card("Wallet • spent today", currency(spentToday()), "TRACK EVERY MOVE", RED);
            card("Calorie lab • today", String.valueOf(caloriesToday()) + " kcal", "ESTIMATED FOOD ENERGY", BLUE);
            section("QUICK ACCESS");
            addAction("＋  Add an expense", RED, () -> expenseDialog());
            addAction("＋  Log food", BLUE, () -> foodDialog());
            section("SYSTEM NOTES");
            TextView note = text("Your entries stay on this device. Use the Wallet and Calorie tabs to review your records.",13,MUTED,false);
            note.setPadding(4,0,4,14); body.addView(note);
        } else if (p.equals("wallet")) {
            card("Spent this month", currency(spentMonth()), "TOTAL EXPENSES", RED);
            card("Income recorded", currency(prefs.getFloat("income",0f)), "MANUALLY ENTERED INCOME", BLUE);
            card("Estimated balance", currency(prefs.getFloat("income",0f)-spentMonth()), "INCOME MINUS EXPENSES", Color.rgb(100,240,180));
            section("ADD RECORD");
            addAction("＋  Add expense", RED, () -> expenseDialog());
            addAction("＋  Add income", BLUE, () -> incomeDialog());
            section("RECENT EXPENSES");
            List<String> entries = getEntries("expenses");
            if(entries.isEmpty()) body.addView(text("No expenses yet. Add your first record above.",13,MUTED,false));
            else for(int i=entries.size()-1;i>=0 && i>=entries.size()-8;i--) body.addView(entryRow(entries.get(i),RED));
            addAction("Clear all wallet records", PANEL, () -> confirmClear("expenses"));
        } else {
            card("Calories logged today", caloriesToday()+" kcal", "ESTIMATES ONLY • NOT MEDICAL ADVICE", BLUE);
            section("LOG FOOD");
            addAction("＋  Add food and calories", BLUE, () -> foodDialog());
            section("TODAY'S FOOD");
            List<String> entries = getEntries("foods");
            String today = dayKey();
            boolean any = false;
            for(int i=entries.size()-1;i>=0;i--) {
                String[] parts=entries.get(i).split("\\|",4);
                if(parts.length==4 && parts[0].equals(today)) { body.addView(entryRow(parts[1]+"  •  "+parts[2]+" kcal",BLUE)); any=true; }
            }
            if(!any) body.addView(text("No food logged today. Calories are approximate and depend on portions and preparation.",13,MUTED,false));
            addAction("Clear all food records", PANEL, () -> confirmClear("foods"));
        }
    }
    private void addAction(String label, int color, Runnable action) {
        TextView b = button(label,color); LinearLayout.LayoutParams p=lp(-1,-2); p.setMargins(0,5,0,5);
        body.addView(b,p); b.setOnClickListener(v -> action.run());
    }
    private View entryRow(String label, int accent) {
        TextView v=text("•  "+label,13,WHITE,false); v.setPadding(12,12,12,12);
        v.setBackground(shape(PANEL,accent,14)); LinearLayout.LayoutParams p=lp(-1,-2);p.setMargins(0,4,0,4);v.setLayoutParams(p); return v;
    }
    private void expenseDialog() {
        LinearLayout form=column(); form.setPadding(4,8,4,0);
        EditText name=edit("Expense name (e.g. transport)",InputType.TYPE_CLASS_TEXT);
        EditText amount=edit("Amount in EGP",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        EditText category=edit("Category (food, transport, etc.)",InputType.TYPE_CLASS_TEXT);
        form.addView(name,lp(-1,52));gap(form,8);form.addView(amount,lp(-1,52));gap(form,8);form.addView(category,lp(-1,52));
        new AlertDialog.Builder(this).setTitle("New expense").setView(form).setNegativeButton("Cancel",null).setPositiveButton("Save",(d,w)->{
            double a=parse(amount.getText().toString());
            if(name.getText().length()==0 || a<=0){toast("Enter a name and a valid amount.");return;}
            addEntry("expenses", dayKey()+"|"+safe(name.getText().toString())+"|"+a+" EGP|"+safe(category.getText().toString()));
            showPage("wallet");
        }).show();
    }
    private void incomeDialog() {
        EditText e=edit("Income amount in EGP",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        new AlertDialog.Builder(this).setTitle("Add income").setView(e).setNegativeButton("Cancel",null).setPositiveButton("Save",(d,w)->{
            double a=parse(e.getText().toString()); if(a<=0){toast("Enter a valid amount.");return;}
            prefs.edit().putFloat("income",prefs.getFloat("income",0f)+(float)a).apply(); showPage("wallet");
        }).show();
    }
    private void foodDialog() {
        LinearLayout form=column();form.setPadding(4,8,4,0);
        EditText name=edit("Food name",InputType.TYPE_CLASS_TEXT);
        EditText kcal=edit("Calories (kcal) from label/estimate",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        form.addView(name,lp(-1,52));gap(form,8);form.addView(kcal,lp(-1,52));
        new AlertDialog.Builder(this).setTitle("Log food").setMessage("Enter an estimate from the food label or a trusted nutrition source.").setView(form).setNegativeButton("Cancel",null).setPositiveButton("Save",(d,w)->{
            double a=parse(kcal.getText().toString());if(name.getText().length()==0||a<=0){toast("Enter food and a valid calorie estimate.");return;}
            addEntry("foods",dayKey()+"|"+safe(name.getText().toString())+"|"+(int)Math.round(a)+"|kcal");
            showPage("calories");
        }).show();
    }
    private void confirmClear(String key) {
        new AlertDialog.Builder(this).setTitle("Clear records?").setMessage("This removes saved "+key+" records from this device.").setNegativeButton("Cancel",null).setPositiveButton("Clear",(d,w)->{prefs.edit().remove(key).apply();showPage(page);}).show();
    }
    private void addEntry(String key,String entry) {
        List<String> l=getEntries(key);l.add(entry);StringBuilder s=new StringBuilder();for(String x:l){if(s.length()>0)s.append("\n");s.append(x);}prefs.edit().putString(key,s.toString()).apply();
    }
    private List<String> getEntries(String key) {
        String raw=prefs.getString(key,"");List<String> l=new ArrayList<>();if(!raw.isEmpty())l.addAll(Arrays.asList(raw.split("\n")));return l;
    }
    private double spentToday(){double sum=0;for(String s:getEntries("expenses")){String[] p=s.split("\\|",4);if(p.length>=3&&p[0].equals(dayKey()))sum+=parse(p[2].replace(" EGP",""));}return sum;}
    private double spentMonth(){double sum=0;String month=new SimpleDateFormat("yyyy-MM",Locale.US).format(new Date());for(String s:getEntries("expenses")){String[] p=s.split("\\|",4);if(p.length>=3&&p[0].startsWith(month))sum+=parse(p[2].replace(" EGP",""));}return sum;}
    private int caloriesToday(){int sum=0;for(String s:getEntries("foods")){String[] p=s.split("\\|",4);if(p.length>=3&&p[0].equals(dayKey()))sum+=(int)parse(p[2]);}return sum;}
    private String dayKey(){return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());}
    private String currency(double v){return money.format(v)+" EGP";}
    private double parse(String s){try{return Double.parseDouble(s.trim());}catch(Exception e){return 0;}}
    private String safe(String s){return s.replace("|"," ").replace("\n"," ").trim();}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}

    private class WebBackground extends View {
        Paint p=new Paint(3);
        WebBackground(){super(MainActivity.this);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        @Override protected void onDraw(Canvas c){
            super.onDraw(c);c.drawColor(BG);float w=getWidth(),h=getHeight();
            p.setColor(Color.argb(24,50,155,255));p.setStrokeWidth(1);
            for(int x=0;x<w;x+=34)c.drawLine(x,0,x,h,p);
            for(int y=0;y<h;y+=34)c.drawLine(0,y,w,y,p);
            p.setColor(Color.argb(30,255,55,82));p.setStrokeWidth(1.5f);
            float cx=w*.78f,cy=h*.17f;
            for(int r=30;r<220;r+=35)c.drawCircle(cx,cy,r,p);
            for(int a=0;a<360;a+=45){double rad=Math.toRadians(a);c.drawLine(cx,cy,cx+(float)Math.cos(rad)*260,cy+(float)Math.sin(rad)*260,p);}
        }
    }
}
